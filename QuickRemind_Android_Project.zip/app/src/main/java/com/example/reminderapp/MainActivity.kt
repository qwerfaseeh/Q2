package com.example.reminderapp

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Circle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import coil.compose.AsyncImage
import com.example.reminderapp.data.Reminder
import com.example.reminderapp.data.ReminderDatabase
import com.example.reminderapp.receiver.AlarmReceiver
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {

    private val database by lazy { ReminderDatabase.getDatabase(this) }
    private var sharedTextState = mutableStateOf<String?>(null)
    private var sharedImageUriState = mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleIncomingIntent(intent)

        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Color(0xFF1E88E5),
                    secondary = Color(0xFF26A69A),
                    surface = Color(0xFFF8F9FA)
                )
            ) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.surface
                ) {
                    ReminderApp(
                        database = database,
                        sharedText = sharedTextState.value,
                        sharedImageUri = sharedImageUriState.value,
                        onClearSharedState = {
                            sharedTextState.value = null
                            sharedImageUriState.value = null
                        },
                        onScheduleAlarm = { reminder ->
                            scheduleAlarm(reminder)
                        }
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun handleIncomingIntent(intent: Intent?) {
        if (intent == null) return
        if (intent.action == Intent.ACTION_SEND) {
            val mimeType = intent.type ?: ""
            if (mimeType.startsWith("text/")) {
                val text = intent.getStringExtra(Intent.EXTRA_TEXT)
                sharedTextState.value = text
            } else if (mimeType.startsWith("image/")) {
                val imageUri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
                }
                sharedImageUriState.value = imageUri?.toString()
            }
        }
    }

    private fun scheduleAlarm(reminder: Reminder) {
        val timestamp = reminder.reminderTimestamp ?: return
        if (timestamp <= System.currentTimeMillis()) return

        val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, AlarmReceiver::class.java).apply {
            putExtra(AlarmReceiver.EXTRA_TASK_ID, reminder.id)
            putExtra(AlarmReceiver.EXTRA_TITLE, reminder.title)
            putExtra(AlarmReceiver.EXTRA_NOTES, reminder.notes)
        }
        val pendingIntent = PendingIntent.getBroadcast(
            this,
            reminder.id.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        alarmManager.setExactAndAllowWhileIdle(
            AlarmManager.RTC_WAKEUP,
            timestamp,
            pendingIntent
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReminderApp(
    database: ReminderDatabase,
    sharedText: String?,
    sharedImageUri: String?,
    onClearSharedState: () -> Unit,
    onScheduleAlarm: (Reminder) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val reminders by database.reminderDao().getAllReminders().collectAsState(initial = emptyList())

    var showAddDialog by remember { mutableStateOf(false) }
    var taskTitle by remember { mutableStateOf("") }
    var taskNotes by remember { mutableStateOf("") }
    var attachedImageUri by remember { mutableStateOf<String?>(null) }
    var reminderTimeMillis by remember { mutableStateOf<Long?>(null) }

    // When shared content is received from another app via Intent.ACTION_SEND:
    LaunchedEffect(sharedText, sharedImageUri) {
        if (sharedText != null || sharedImageUri != null) {
            taskTitle = sharedText?.take(40) ?: "Shared Item"
            taskNotes = sharedText ?: ""
            attachedImageUri = sharedImageUri
            showAddDialog = true
            onClearSharedState()
        }
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        attachedImageUri = uri?.toString()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("QuickRemind", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    taskTitle = ""
                    taskNotes = ""
                    attachedImageUri = null
                    reminderTimeMillis = null
                    showAddDialog = true
                },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Reminder")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(16.dp)
        ) {
            val pendingCount = reminders.count { !it.isCompleted }
            Text(
                text = if (pendingCount == 0 && reminders.isNotEmpty()) "All done! 🎉" else "$pendingCount pending",
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                color = Color.Gray,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            if (reminders.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No reminders yet. Tap + to add one!", color = Color.Gray)
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(reminders, key = { it.id }) { item ->
                        ReminderCard(
                            item = item,
                            onToggleComplete = {
                                coroutineScope.launch {
                                    database.reminderDao().update(item.copy(isCompleted = !item.isCompleted))
                                }
                            },
                            onDelete = {
                                coroutineScope.launch {
                                    database.reminderDao().delete(item)
                                }
                            },
                            onSnooze = {
                                val newTime = System.currentTimeMillis() + 10 * 60 * 1000
                                val updated = item.copy(reminderTimestamp = newTime)
                                coroutineScope.launch {
                                    database.reminderDao().update(updated)
                                    onScheduleAlarm(updated)
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("New Reminder", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = taskTitle,
                        onValueChange = { taskTitle = it },
                        label = { Text("Title *") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = taskNotes,
                        onValueChange = { taskNotes = it },
                        label = { Text("Notes / Pasted Text") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 3
                    )

                    // Image picker button
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Button(
                            onClick = { photoPickerLauncher.launch("image/*") },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Image, contentDescription = null)
                            Spacer(Modifier.width(4.dp))
                            Text(if (attachedImageUri != null) "Change Photo" else "Attach Photo")
                        }
                        if (attachedImageUri != null) {
                            IconButton(onClick = { attachedImageUri = null }) {
                                Icon(Icons.Default.Close, contentDescription = "Remove photo", tint = Color.Red)
                            }
                        }
                    }

                    // Quick Reminder Timer Chip (+15 min)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = reminderTimeMillis != null,
                            onClick = {
                                reminderTimeMillis = if (reminderTimeMillis == null) {
                                    System.currentTimeMillis() + 15 * 60 * 1000
                                } else null
                            },
                            label = {
                                Text(if (reminderTimeMillis != null) "Alarm: in 15m" else "+15m Alarm")
                            }
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (taskTitle.isNotBlank()) {
                            val newReminder = Reminder(
                                title = taskTitle.trim(),
                                notes = taskNotes.trim(),
                                imageUri = attachedImageUri,
                                reminderTimestamp = reminderTimeMillis,
                                isCompleted = false
                            )
                            coroutineScope.launch {
                                val newId = database.reminderDao().insert(newReminder)
                                if (reminderTimeMillis != null) {
                                    onScheduleAlarm(newReminder.copy(id = newId))
                                }
                            }
                            showAddDialog = false
                        }
                    }
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun ReminderCard(
    item: Reminder,
    onToggleComplete: () -> Unit,
    onDelete: () -> Unit,
    onSnooze: () -> Unit
) {
    val cardBg by animateColorAsState(
        targetValue = if (item.isCompleted) Color(0xFFF1F3F4) else Color.White,
        label = "bg"
    )

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = cardBg)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onToggleComplete) {
                    if (item.isCompleted) {
                        Icon(Icons.Default.CheckCircle, "Done", tint = Color(0xFF2E7D32))
                    } else {
                        Icon(Icons.Outlined.Circle, "Incomplete", tint = Color.Gray)
                    }
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = item.title,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 15.sp,
                        textDecoration = if (item.isCompleted) TextDecoration.LineThrough else TextDecoration.None
                    )
                    if (item.notes.isNotBlank()) {
                        Text(
                            text = item.notes,
                            fontSize = 12.sp,
                            color = Color.Gray,
                            textDecoration = if (item.isCompleted) TextDecoration.LineThrough else TextDecoration.None
                        )
                    }
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, "Delete", tint = Color(0xFFE57373))
                }
            }

            if (!item.imageUri.isNullOrBlank()) {
                AsyncImage(
                    model = item.imageUri,
                    contentDescription = "Attached photo",
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                        .clip(RoundedCornerShape(8.dp)),
                    contentScale = ContentScale.Crop
                )
            }

            if (item.reminderTimestamp != null && !item.isCompleted) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val sdf = SimpleDateFormat("h:mm a, MMM d", Locale.getDefault())
                    val formatted = sdf.format(Date(item.reminderTimestamp))
                    Text("⏰ Alarm: $formatted", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                    TextButton(onClick = onSnooze) {
                        Text("Snooze 10m", fontSize = 11.sp)
                    }
                }
            }
        }
    }
}
