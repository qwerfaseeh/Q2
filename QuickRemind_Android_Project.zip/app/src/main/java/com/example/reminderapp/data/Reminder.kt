package com.example.reminderapp.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "reminders")
data class Reminder(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val notes: String = "",
    val imageUri: String? = null,
    val reminderTimestamp: Long? = null, // epoch millis or null
    val isCompleted: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
